## SPL

Gate pass and sample management system

#### License

mit