# Copyright (c) 2024, Ali Raza and contributors
# For license information, please see license.txt

# import frappe
from frappe.model.document import Document


class GatePassItem(Document):
	pass
